import React, {useState} from 'react';
import {GoTriangleUp, GoTriangleDown} from 'react-icons/go';

function ProductQuantity(){
    return
}