

import ImageGallery from 'react-image-gallery';


function GalleryPage(){
   const images ={
    original: '/Users/junseo/Desktop/OSU/3rd term/CS 290/M8/a8-seoj2-portfolio/frontend/public/images/Church-Oslo.jpeg',
    thumbnail:'',
    description: '',
    originalHeight: '450px'
   };
    return(
        <>
            <h2>Gallery</h2>
            <article  >
                
            </article>
        </>
    );
}
        
export default GalleryPage;  